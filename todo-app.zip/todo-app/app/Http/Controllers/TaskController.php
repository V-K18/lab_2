<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class TaskController extends Controller
{

    public function index()
    {
        $tasks = [
            ['id' => 1, 'title' => "Task 1", 'description' => "Task Details 1"],
            ['id' => 2, 'title' => "Task 2", 'description' => "Task Details 2"],
            ['id' => 3, 'title' => "Task 3", 'description' => "Task Details 3"],
            ['id' => 4, 'title' => "Task 4", 'description' => "Task Details 4"],
            ['id' => 5, 'title' => "Task 5", 'description' => "Task Details 5"],
            ['id' => 6, 'title' => "Task 6", 'description' => "Task Details 6"]
        ];

        return view('tasks.index', ['tasks' => $tasks]);
    }


    public function create()
    {
        return view('tasks.create');
    }

    public function store(Request $request) {}


    public function show($id)
    {

        $task = [
            'id' => $id,
            'title' => 'Task ' . $id,
            'description' => 'Description for task ' . $id
        ];

        return view('tasks.show', ['task' => $task]);
    }

    public function edit(string $id)
    {
        return view('tasks.edit');
    }

    public function update(Request $request, string $id) {}

    public function destroy(string $id) {}
}
